from django.apps import AppConfig


class SortConfig(AppConfig):
    name = 'sort'
